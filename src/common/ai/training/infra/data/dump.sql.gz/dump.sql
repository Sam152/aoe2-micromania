--
-- PostgreSQL database dump
--

\restrict IiJzc6gZeu64Uf1Iy2E5HolxvWuOmtxRVOkzhGsqvtIgn1ZheEjg5BFUG4dfDsf

-- Dumped from database version 18.4 (Debian 18.4-1.pgdg13+1)
-- Dumped by pg_dump version 18.4 (Debian 18.4-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: bots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bots (id, bot_name, generation, elo, wins, losses, draws, games_since_last_prune, is_active, generation_champion, tree) FROM stdin;
67	intelligent-sweet-pasteur	14	1600	0	0	0	0	t	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 156, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "magnitude": {"type": "LITERAL", "value": 281, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "pointB": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}, "positionInTicksAmount": {"type": "LITERAL", "value": 26, "dataType": "tickCount", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}, "distance": {"type": "LITERAL", "value": 27, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "tickCountLessThan", "invert": true, "params": {"leftTicks": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}, "rightTicks": {"type": "LITERAL", "value": 76, "dataType": "tickCount", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}, "positionInTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 279, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 138, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "groupIndexEquals", "invert": true, "params": {"groupIndexLeft": {"type": "BLACKBOARD", "params": {}, "dataType": "groupIndex", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeIndex"}, "groupIndexRight": {"type": "LITERAL", "value": 3, "dataType": "groupIndex", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentArcherWithinMangoMinimumRange"}}, "nodeType": "action"}, {"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}}
68	elastic-compassionate-noyce	14	1600	0	0	0	0	t	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 156, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "magnitude": {"type": "LITERAL", "value": 281, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 134, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}, "positionInTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"nodes": [{"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}, {"type": "unitCountGreaterThan", "invert": false, "params": {"leftUnitCount": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "opponentUnitCountByType"}, "rightUnitCount": {"type": "LITERAL", "value": 38, "dataType": "unitCount", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "FORMATION_SPREAD", "params": {}, "nodeType": "action"}, {"type": "MERGE_GROUP", "params": {}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}, {"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
69	flamboyant-xenodochial-euclid	14	1600	0	0	0	0	t	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 156, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "magnitude": {"type": "LITERAL", "value": 281, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "tickCountEquals", "invert": false, "params": {"leftTicks": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}, "rightTicks": {"type": "LITERAL", "value": 85, "dataType": "tickCount", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "opponentHasUnitType"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 146, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"type": "ATTACK_GROUND", "params": {"attackGroundPosition": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
70	friendly-authentic-gagarin	14	1600	0	0	0	0	t	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 156, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "magnitude": {"type": "LITERAL", "value": 281, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupHasAnyReloading"}}, "nodeType": "condition"}, {"type": "tickCountEquals", "invert": true, "params": {"leftTicks": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}, "rightTicks": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "condition"}, {"type": "groupIndexGreaterThan", "invert": false, "params": {"groupIndexLeft": {"type": "BLACKBOARD", "params": {}, "dataType": "groupIndex", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeIndex"}, "groupIndexRight": {"type": "LITERAL", "value": 0, "dataType": "groupIndex", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}, "positionInTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "nodeType": "action"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
11	vigorous-modest-tharp	2	1407	0	16	0	0	f	f	{"0": {"nodes": [{"nodes": [{"nodes": [{"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 47, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 13, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "magnitude": {"type": "LITERAL", "value": 192, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 308, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "sequence"}], "nodeType": "selector"}, {"type": "unitCountEquals", "invert": true, "params": {"leftUnitCount": {"type": "BLACKBOARD", "params": {}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeGroupCount"}, "rightUnitCount": {"type": "BLACKBOARD", "params": {}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "groupUnitCount"}}, "nodeType": "condition"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [], "nodeType": "selector"}}
1	mystifying-zealous-krueger	0	1600	0	0	0	0	f	t	{"0": {"nodes": [], "nodeType": "selector"}, "1": {"nodes": [], "nodeType": "selector"}, "2": {"nodes": [], "nodeType": "selector"}}
3	interesting-flamboyant-noether	1	1465	4	0	12	0	f	f	{"0": {"nodes": [{"type": "FORMATION_SPREAD", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "2": {"nodes": [], "nodeType": "selector"}}
63	keen-zealous-lalande	13	1460	2	14	0	0	f	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 156, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "magnitude": {"type": "LITERAL", "value": 281, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}}
44	zen-fervent-engelbart	9	1502	4	12	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentArcherWithinMangoMinimumRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}, {"type": "FORMATION_SPREAD", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}}
58	dazzling-authentic-hellman	12	1587	7	9	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}}, "nodeType": "action"}], "nodeType": "sequence"}, {"type": "MERGE_GROUP", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
66	blissful-dazzling-hermann	13	1600	8	8	0	0	f	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 156, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "magnitude": {"type": "LITERAL", "value": 281, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentArcherWithinMangoMinimumRange"}}, "nodeType": "action"}, {"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}}
56	gracious-zealous-miatselski	11	1457	2	14	0	0	f	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 275, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "magnitude": {"type": "LITERAL", "value": 136, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "MERGE_GROUP", "params": {}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "sequence"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
46	great-eager-lewin	9	1476	3	13	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 33, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"type": "FORMATION_SPREAD", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}}
45	inspiring-jolly-curran	9	1691	12	0	4	0	f	t	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "pointB": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "distance": {"type": "LITERAL", "value": 323, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "formationEquals", "invert": true, "params": {"leftFormation": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "formation", "nodeType": "dataValue", "blackboardKey": "opponentFormationByType"}, "rightFormation": {"type": "BLACKBOARD", "params": {}, "dataType": "formation", "nodeType": "dataValue", "blackboardKey": "groupFormation"}}, "nodeType": "condition"}, {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}}
53	happy-elastic-owen	11	1663	11	5	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
23	competent-charming-banzai	5	1646	10	5	1	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}}
27	vigorous-elated-hayes	6	1508	4	12	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 260, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"type": "unitCountEquals", "invert": true, "params": {"leftUnitCount": {"type": "BLACKBOARD", "params": {}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "groupUnitCount"}, "rightUnitCount": {"type": "LITERAL", "value": 22, "dataType": "unitCount", "nodeType": "dataValue"}}, "nodeType": "condition"}], "nodeType": "selector"}}
35	brave-charming-shamir	7	1412	0	16	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 110, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 386, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 61, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 215, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}, "positionInTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
42	trusting-laughing-mersin	9	1586	8	4	4	0	f	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 21, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}}
10	elegant-festive-bardeen	2	1501	4	12	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}, "positionInTicksAmount": {"type": "LITERAL", "value": 3, "dataType": "tickCount", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "nodeType": "action"}, {"type": "booleanIsTrue", "invert": true, "params": {"subject": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "opponentHasUnitType"}}, "nodeType": "condition"}, {"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 84, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "magnitude": {"type": "LITERAL", "value": 125, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}}, "nodeType": "action"}], "nodeType": "sequence"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
5	mystifying-magical-chelikowsky	1	1372	0	16	0	0	f	f	{"0": {"nodes": [{"type": "groupIndexEquals", "invert": false, "params": {"groupIndexLeft": {"type": "BLACKBOARD", "params": {}, "dataType": "groupIndex", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeIndex"}, "groupIndexRight": {"type": "LITERAL", "value": 0, "dataType": "groupIndex", "nodeType": "dataValue"}}, "nodeType": "condition"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "ATTACK_GROUND", "params": {"attackGroundPosition": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "2": {"nodes": [], "nodeType": "selector"}}
59	ruminant-curious-shaw	12	1550	6	10	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "groupIndexGreaterThan", "invert": true, "params": {"groupIndexLeft": {"type": "BLACKBOARD", "params": {}, "dataType": "groupIndex", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeIndex"}, "groupIndexRight": {"type": "LITERAL", "value": 0, "dataType": "groupIndex", "nodeType": "dataValue"}}, "nodeType": "condition"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
16	quizzical-nice-robinson	3	1399	0	12	4	0	f	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}, "positionInTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "nodeType": "action"}, {"type": "unitCountEquals", "invert": false, "params": {"leftUnitCount": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "opponentUnitCountByType"}, "rightUnitCount": {"type": "BLACKBOARD", "params": {}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "groupUnitCount"}}, "nodeType": "condition"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 24, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 466, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}}
37	authentic-serene-padilla	8	1719	13	3	0	0	f	t	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": true, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 3, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 72, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "FORMATION_SPREAD", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "formationEquals", "invert": true, "params": {"leftFormation": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "formation", "nodeType": "dataValue", "blackboardKey": "opponentFormationByType"}, "rightFormation": {"type": "BLACKBOARD", "params": {}, "dataType": "formation", "nodeType": "dataValue", "blackboardKey": "groupFormation"}}, "nodeType": "condition"}, {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}}
57	dazzling-trusting-hoffman	12	1786	16	0	0	0	f	t	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 156, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "magnitude": {"type": "LITERAL", "value": 281, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
8	flamboyant-happy-fermat	2	1686	12	0	4	0	f	t	{"0": {"nodes": [], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 23, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}, {"type": "SPLIT_GROUP", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
61	youthful-eager-romano	12	1512	4	12	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
12	great-frosty-montalcini	3	1778	16	0	0	0	f	t	{"0": {"nodes": [{"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 244, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "magnitude": {"type": "LITERAL", "value": 409, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"nodes": [{"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "sequence"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 24, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 466, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}}
34	peaceful-elegant-mullins	7	1693	12	4	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": true, "params": {"pointA": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 314, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "magnitude": {"type": "LITERAL", "value": 49, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "pointB": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "distance": {"type": "LITERAL", "value": 487, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}, "positionInTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
40	peaceful-heuristic-correll	8	1648	10	6	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "tickCountLessThan", "invert": true, "params": {"leftTicks": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}, "rightTicks": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "condition"}, {"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}, "positionInTicksAmount": {"type": "LITERAL", "value": 97, "dataType": "tickCount", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "nodeType": "action"}, {"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
55	objective-vigilant-murad	11	1602	8	8	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 334, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentArcherWithinMangoMinimumRange"}, "positionInTicksAmount": {"type": "LITERAL", "value": 41, "dataType": "tickCount", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
47	flamboyant-jovial-hall	10	1578	8	0	8	0	f	t	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "pointB": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "distance": {"type": "LITERAL", "value": 323, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "unitCountEquals", "invert": false, "params": {"leftUnitCount": {"type": "BLACKBOARD", "params": {}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeGroupCount"}, "rightUnitCount": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "opponentUnitCountByType"}}, "nodeType": "condition"}, {"nodes": [{"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": true, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "pointB": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "distance": {"type": "LITERAL", "value": 309, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}], "nodeType": "selector"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}}
32	quizzical-confident-newton	7	1746	14	2	0	0	f	t	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "formationEquals", "invert": true, "params": {"leftFormation": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "formation", "nodeType": "dataValue", "blackboardKey": "opponentFormationByType"}, "rightFormation": {"type": "BLACKBOARD", "params": {}, "dataType": "formation", "nodeType": "dataValue", "blackboardKey": "groupFormation"}}, "nodeType": "condition"}, {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}, "positionInTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
39	intelligent-nice-gian	8	1611	9	7	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 74, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 229, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 17, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"nodes": [{"type": "unitCountEquals", "invert": false, "params": {"leftUnitCount": {"type": "BLACKBOARD", "params": {}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeGroupCount"}, "rightUnitCount": {"type": "BLACKBOARD", "params": {}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "groupUnitCount"}}, "nodeType": "condition"}], "nodeType": "selector"}], "nodeType": "selector"}}
6	sweet-wonderful-brattain	1	1465	4	0	12	0	f	f	{"0": {"nodes": [], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [], "nodeType": "selector"}}
25	authentic-nostalgic-hertz	5	1735	14	2	0	0	f	t	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "unitCountEquals", "invert": true, "params": {"leftUnitCount": {"type": "BLACKBOARD", "params": {}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeGroupCount"}, "rightUnitCount": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "globalOwnedUnitsOfTypeCount"}}, "nodeType": "condition"}, {"type": "SPLIT_GROUP", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
41	beloved-xenodochial-wescoff	8	1513	4	12	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 277, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
48	unruffled-stoic-brown	10	1396	0	16	0	0	f	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 213, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 151, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentArcherWithinMangoMinimumRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 419, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}, "positionInTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}, "pointB": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "distance": {"type": "LITERAL", "value": 361, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}}
65	exciting-jovial-cohen	13	1668	11	5	0	0	f	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 156, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "magnitude": {"type": "LITERAL", "value": 281, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentArcherWithinMangoMinimumRange"}, "positionInTicksAmount": {"type": "LITERAL", "value": 51, "dataType": "tickCount", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "nodeType": "action"}], "nodeType": "sequence"}, {"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": true, "params": {"pointA": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}, "positionInTicksAmount": {"type": "LITERAL", "value": 94, "dataType": "tickCount", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}, "distance": {"type": "LITERAL", "value": 211, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
49	elegant-admiring-kepler	10	1578	8	0	8	0	f	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "pointB": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "distance": {"type": "LITERAL", "value": 323, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "unitCountGreaterThan", "invert": true, "params": {"leftUnitCount": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "opponentUnitCountByType"}, "rightUnitCount": {"type": "BLACKBOARD", "params": {}, "dataType": "unitCount", "nodeType": "dataValue", "blackboardKey": "groupUnitCount"}}, "nodeType": "condition"}, {"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentArcherWithinMangoMinimumRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 264, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 240, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
36	reverent-heuristic-pascal	7	1533	5	11	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}, "positionInTicksAmount": {"type": "LITERAL", "value": 21, "dataType": "tickCount", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
7	focused-frosty-jepsen	2	1592	8	8	0	0	f	f	{"0": {"nodes": [{"type": "groupIndexEquals", "invert": false, "params": {"groupIndexLeft": {"type": "BLACKBOARD", "params": {}, "dataType": "groupIndex", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeIndex"}, "groupIndexRight": {"type": "BLACKBOARD", "params": {}, "dataType": "groupIndex", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeIndex"}}, "nodeType": "condition"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 342, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "magnitude": {"type": "LITERAL", "value": 333, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "FORMATION_SPREAD", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
62	heuristic-funny-payne	13	1786	16	0	0	0	f	t	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 156, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "magnitude": {"type": "LITERAL", "value": 281, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 146, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"type": "ATTACK_GROUND", "params": {"attackGroundPosition": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}, {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
64	musing-youthful-nobel	13	1486	3	13	0	0	f	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 156, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "magnitude": {"type": "LITERAL", "value": 281, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupHasAnyReloading"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
17	vigilant-confident-galois	4	1593	8	4	4	0	f	f	{"0": {"nodes": [{"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 19, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupAveragePosition"}, "magnitude": {"type": "LITERAL", "value": 406, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}}
52	youthful-confident-brahmagupta	11	1680	11	5	0	0	f	t	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "pointB": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "distance": {"type": "LITERAL", "value": 53, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
28	zealous-clever-sharp	6	1695	12	4	0	0	f	t	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}, "positionInTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
19	jolly-practical-romito	4	1593	8	4	4	0	f	f	{"0": {"nodes": [{"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "tickCountEquals", "invert": true, "params": {"leftTicks": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}, "rightTicks": {"type": "LITERAL", "value": 0, "dataType": "tickCount", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"type": "FORMATION_SPREAD", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
43	affectionate-recursing-heyrovsky	9	1617	9	7	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": true, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "pointB": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "distance": {"type": "LITERAL", "value": 118, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupHasAnyReloading"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 96, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "magnitude": {"type": "LITERAL", "value": 446, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "nodeType": "action"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "LITERAL", "value": 45, "dataType": "tickCount", "nodeType": "dataValue"}}, "nodeType": "action"}], "nodeType": "sequence"}], "nodeType": "selector"}}
51	beautiful-wizardly-goolya	10	1578	8	0	8	0	f	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}, "pointB": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "distance": {"type": "LITERAL", "value": 323, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": true, "params": {"pointA": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 148, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "magnitude": {"type": "LITERAL", "value": 462, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 200, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 27, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 200, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 372, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
60	quirky-vigilant-ansell	12	1565	7	9	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "FORMATION_SPREAD", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "tickCountLessThan", "invert": false, "params": {"leftTicks": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}, "rightTicks": {"type": "LITERAL", "value": 81, "dataType": "tickCount", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "SPLIT_GROUP", "params": {}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
30	infallible-interesting-chatelet	6	1413	0	16	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "opponentHasUnitType"}}, "nodeType": "condition"}, {"type": "groupIndexGreaterThan", "invert": true, "params": {"groupIndexLeft": {"type": "BLACKBOARD", "params": {}, "dataType": "groupIndex", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeIndex"}, "groupIndexRight": {"type": "BLACKBOARD", "params": {}, "dataType": "groupIndex", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeIndex"}}, "nodeType": "condition"}, {"type": "tickCountLessThan", "invert": false, "params": {"leftTicks": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}, "rightTicks": {"type": "LITERAL", "value": 7, "dataType": "tickCount", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}, {"type": "MERGE_GROUP", "params": {}, "nodeType": "action"}], "nodeType": "sequence"}, {"type": "FORMATION_SPREAD", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
33	optimistic-practical-montalcini	7	1616	9	7	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}, "positionInTicksAmount": {"type": "LITERAL", "value": 6, "dataType": "tickCount", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "nodeType": "action"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}}
38	wizardly-peaceful-khorana	8	1509	4	12	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 335, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 5, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 74, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 229, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 36, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 92, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 416, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 152, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "MERGE_GROUP", "params": {}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}}
31	blissful-objective-banach	6	1691	12	4	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 313, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"movingUnit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}, "positionInTicksAmount": {"type": "LITERAL", "value": 12, "dataType": "tickCount", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentUnitMovementTowardsVector"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"type": "groupIndexGreaterThan", "invert": true, "params": {"groupIndexLeft": {"type": "BLACKBOARD", "params": {}, "dataType": "groupIndex", "nodeType": "dataValue", "blackboardKey": "groupMetaUnitTypeIndex"}, "groupIndexRight": {"type": "LITERAL", "value": 3, "dataType": "groupIndex", "nodeType": "dataValue"}}, "nodeType": "condition"}], "nodeType": "selector"}}
22	eloquent-happy-mcclintock	5	1571	7	8	1	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}}
26	musing-friendly-tankersley	5	1507	4	12	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}}
24	stoic-stoic-tankersley	5	1509	4	12	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}}
54	nice-stoic-kanson	11	1598	8	8	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingPositionByType"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByTypeNotInMinRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}}
4	focused-beautiful-gorney	1	1465	4	0	12	0	f	f	{"0": {"nodes": [], "nodeType": "selector"}, "1": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}, {"nodes": [{"type": "formationEquals", "invert": false, "params": {"leftFormation": {"type": "BLACKBOARD", "params": {}, "dataType": "formation", "nodeType": "dataValue", "blackboardKey": "groupFormation"}, "rightFormation": {"type": "LITERAL", "value": "LINE", "dataType": "formation", "nodeType": "dataValue"}}, "nodeType": "condition"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [], "nodeType": "selector"}}
15	priceless-festive-lovelace	3	1393	0	9	7	0	f	f	{"0": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 161, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"type": "tickCountLessThan", "invert": true, "params": {"leftTicks": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}, "rightTicks": {"type": "LITERAL", "value": 38, "dataType": "tickCount", "nodeType": "dataValue"}}, "nodeType": "condition"}], "nodeType": "sequence"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 24, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 466, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}}
18	serene-problematic-sanderson	4	1780	16	0	0	0	f	t	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 24, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 466, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}}
14	focused-jolly-shaw	3	1524	5	8	3	0	f	f	{"0": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "LITERAL", "value": 42, "dataType": "tickCount", "nodeType": "dataValue"}}, "nodeType": "action"}, {"type": "FORMATION_SPREAD", "params": {}, "nodeType": "action"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 141, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}, "magnitude": {"type": "LITERAL", "value": 465, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "formationEquals", "invert": true, "params": {"leftFormation": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "formation", "nodeType": "dataValue", "blackboardKey": "opponentFormationByType"}, "rightFormation": {"type": "BLACKBOARD", "params": {}, "dataType": "formation", "nodeType": "dataValue", "blackboardKey": "groupFormation"}}, "nodeType": "condition"}], "nodeType": "sequence"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 24, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 466, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}}
20	ecstatic-ruminant-zhukovsky	4	1407	0	16	0	0	f	f	{"0": {"nodes": [{"type": "tickCountEquals", "invert": true, "params": {"leftTicks": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}, "rightTicks": {"type": "LITERAL", "value": 83, "dataType": "tickCount", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 211, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 127, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "magnitude": {"type": "LITERAL", "value": 409, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "sequence"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 24, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 466, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}}
9	compassionate-confident-kanson	2	1686	12	0	4	0	f	f	{"0": {"nodes": [], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 24, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 466, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}}
29	fervent-affectionate-ellis	6	1693	12	4	0	0	f	f	{"0": {"nodes": [{"type": "vectorDistanceBetweenLessThan", "invert": false, "params": {"pointA": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}, "pointB": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 194, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 76, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "distance": {"type": "LITERAL", "value": 411, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "nodeType": "condition"}, {"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 117, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 306, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 413, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 355, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 204, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 92, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"nodes": [{"type": "SPLIT_GROUP", "params": {}, "nodeType": "action"}], "nodeType": "sequence"}], "nodeType": "selector"}}
13	epic-kind-duke	3	1682	12	4	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 243, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}, "magnitude": {"type": "LITERAL", "value": 305, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"nodes": [{"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 24, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 466, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}}
21	focused-jolly-mikkleson	4	1499	4	12	0	0	f	f	{"0": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 273, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 289, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "globalNonGroupUnitsOfTypeAveragePosition"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}, "magnitude": {"type": "LITERAL", "value": 490, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}, {"type": "DELETE_GROUP", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAveragePosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 24, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}, "magnitude": {"type": "LITERAL", "value": 466, "dataType": "vectorMagnitude", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupUnitVectorFacingDirection"}}, "nodeType": "action"}], "nodeType": "selector"}}
50	epic-determined-buck	10	1486	4	12	0	0	f	f	{"0": {"nodes": [{"type": "MOVE_UNITS", "params": {"direction": {"type": "BLACKBOARD", "params": {"angle": {"type": "LITERAL", "value": 45, "dataType": "vectorAngle", "nodeType": "dataValue"}, "direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentArcherWithinMangoMinimumRange"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "groupVectorFacingDirection"}}, "nodeType": "action"}, {"type": "FORMATION_SPLIT", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "1": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "ARROW", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}], "nodeType": "selector"}, {"type": "IDLE", "params": {"forTicksAmount": {"type": "BLACKBOARD", "params": {"type": {"type": "LITERAL", "value": "MANGO_ROCK", "dataType": "projectileType", "nodeType": "dataValue"}}, "dataType": "tickCount", "nodeType": "dataValue", "blackboardKey": "opponentNextProjectileLandingInTicksTimeByType"}}, "nodeType": "action"}, {"nodes": [{"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitWithPosition": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "unitPosition"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}], "nodeType": "selector"}, "2": {"nodes": [{"type": "booleanIsTrue", "invert": false, "params": {"subject": {"type": "BLACKBOARD", "params": {}, "dataType": "boolean", "nodeType": "dataValue", "blackboardKey": "groupIsConverting"}}, "nodeType": "condition"}, {"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MANGO", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentClosestUnitByType"}}, "nodeType": "action"}, {"nodes": [{"type": "CONVERT", "params": {"unit": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "MONK", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "unitId", "nodeType": "dataValue", "blackboardKey": "opponentMedoidUnitByType"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}}
2	exciting-friendly-collins	1	1465	4	0	12	0	f	t	{"0": {"nodes": [{"nodes": [{"type": "IDLE", "params": {"forTicksAmount": {"type": "LITERAL", "value": 60, "dataType": "tickCount", "nodeType": "dataValue"}}, "nodeType": "action"}], "nodeType": "selector"}], "nodeType": "selector"}, "1": {"nodes": [{"type": "PATROL", "params": {"direction": {"type": "BLACKBOARD", "params": {"unitType": {"type": "LITERAL", "value": "ARCHER", "dataType": "unitType", "nodeType": "dataValue"}}, "dataType": "vector", "nodeType": "dataValue", "blackboardKey": "opponentAverageUnitPositionByType"}}, "nodeType": "action"}, {"type": "FORMATION_LINE", "params": {}, "nodeType": "action"}], "nodeType": "selector"}, "2": {"nodes": [], "nodeType": "selector"}}
\.


--
-- Data for Name: activations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activations (id, bot_id, path, unit_type) FROM stdin;
\.


--
-- Data for Name: match_results; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.match_results (id, bot_id, opponent_id, tick_count, was_winner, match_elo, elo_delta) FROM stdin;
1	5	4	758	f	1600	-16
2	4	5	758	t	1600	16
3	5	2	760	f	1600	-16
4	2	5	760	t	1600	16
5	6	5	760	t	1600	16
6	5	6	760	f	1600	-16
7	5	3	760	f	1600	-16
8	3	5	760	t	1600	16
9	6	2	6000	f	1600	-16
10	2	6	6000	f	1600	-16
11	4	2	6000	f	1600	-16
12	2	4	6000	f	1600	-16
13	6	4	6000	f	1600	-16
14	4	6	6000	f	1600	-16
15	3	2	6000	f	1600	-16
16	2	3	6000	f	1600	-16
17	6	3	6000	f	1600	-16
18	3	4	6000	f	1600	-16
19	3	6	6000	f	1600	-16
20	4	3	6000	f	1600	-16
21	5	2	760	f	1536	-15
22	2	5	760	t	1568	15
23	5	4	758	f	1536	-15
24	4	5	758	t	1568	15
25	5	6	760	f	1536	-15
26	6	5	760	t	1568	15
27	5	3	760	f	1536	-15
28	3	5	760	t	1568	15
29	2	6	6000	f	1568	-16
30	6	2	6000	f	1568	-16
31	2	4	6000	f	1568	-16
32	4	2	6000	f	1568	-16
33	4	6	6000	f	1568	-16
34	6	4	6000	f	1568	-16
35	2	3	6000	f	1568	-16
36	3	2	6000	f	1568	-16
37	4	3	6000	f	1568	-16
38	3	4	6000	f	1568	-16
39	3	6	6000	f	1568	-16
40	6	3	6000	f	1568	-16
41	6	5	760	t	1535	13
42	5	6	760	f	1476	-13
43	2	5	760	t	1535	13
44	5	2	760	f	1476	-13
45	4	5	758	t	1535	13
46	5	4	758	f	1476	-13
47	3	5	760	t	1535	13
48	5	3	760	f	1476	-13
49	4	2	6000	f	1535	-16
50	2	4	6000	f	1535	-16
51	6	2	6000	f	1535	-16
52	2	6	6000	f	1535	-16
53	6	4	6000	f	1535	-16
54	4	6	6000	f	1535	-16
55	3	2	6000	f	1535	-16
56	2	3	6000	f	1535	-16
57	3	4	6000	f	1535	-16
58	4	3	6000	f	1535	-16
59	6	3	6000	f	1535	-16
60	3	6	6000	f	1535	-16
61	5	6	760	f	1424	-13
62	6	5	760	t	1500	13
63	5	2	760	f	1424	-13
64	2	5	760	t	1500	13
65	5	4	758	f	1424	-13
66	4	5	758	t	1500	13
67	5	3	760	f	1424	-13
68	3	5	760	t	1500	13
69	2	6	6000	f	1500	-16
70	6	2	6000	f	1500	-16
71	2	4	6000	f	1500	-16
72	4	2	6000	f	1500	-16
73	4	6	6000	f	1500	-16
74	6	4	6000	f	1500	-16
75	4	3	6000	f	1500	-16
76	3	4	6000	f	1500	-16
77	2	3	6000	f	1500	-16
78	3	2	6000	f	1500	-16
79	3	6	6000	f	1500	-16
80	6	3	6000	f	1500	-16
81	7	8	743	f	1600	-16
82	8	7	743	t	1600	16
83	7	9	743	f	1600	-16
84	9	7	743	t	1600	16
85	7	10	1049	t	1600	16
86	10	7	1049	f	1600	-16
87	10	9	1242	f	1600	-16
88	9	10	1242	t	1600	16
89	8	10	936	t	1600	16
90	10	8	936	f	1600	-16
91	11	9	6000	f	1600	-16
92	9	11	6000	t	1600	16
93	11	8	6000	f	1600	-16
94	8	11	6000	t	1600	16
95	8	9	6000	f	1600	-16
96	9	8	6000	f	1600	-16
97	11	7	6000	f	1600	-16
98	7	11	6000	t	1600	16
99	11	10	6000	f	1600	-16
100	10	11	6000	t	1600	16
101	7	9	743	f	1600	-15
102	9	7	743	t	1632	15
103	7	8	743	f	1600	-15
104	8	7	743	t	1632	15
105	10	7	1124	f	1568	-15
106	7	10	1124	t	1600	15
107	10	8	968	f	1568	-13
108	8	10	968	t	1632	13
109	10	9	1242	f	1568	-13
110	9	10	1242	t	1632	13
111	11	9	6000	f	1536	-12
112	9	11	6000	t	1632	12
113	11	7	6000	f	1536	-13
114	7	11	6000	t	1600	13
115	11	8	6000	f	1536	-12
116	8	11	6000	t	1632	12
117	9	8	6000	f	1632	-16
118	8	9	6000	f	1632	-16
119	11	10	6000	f	1536	-15
120	10	11	6000	t	1568	15
121	9	7	743	t	1656	13
122	7	9	743	f	1598	-13
127	9	10	937	t	1656	11
128	10	9	937	f	1542	-11
129	8	10	936	t	1656	11
130	10	8	936	f	1542	-11
131	8	11	6000	t	1656	9
132	11	8	6000	f	1484	-9
147	10	7	1124	f	1520	-13
148	7	10	1124	t	1596	13
151	11	7	6000	f	1442	-9
152	7	11	6000	t	1596	9
161	12	13	771	t	1600	16
162	13	12	771	f	1600	-16
163	15	13	913	f	1600	-16
164	13	15	913	t	1600	16
165	15	12	876	f	1600	-16
166	12	15	876	t	1600	16
167	16	14	743	f	1600	-16
168	14	16	743	t	1600	16
183	13	12	561	f	1632	-15
184	12	13	561	t	1664	15
185	15	13	913	f	1536	-12
186	13	15	913	t	1632	12
191	14	12	899	f	1568	-12
192	12	14	899	t	1664	12
193	16	13	6000	f	1536	-12
194	13	16	6000	t	1632	12
195	16	12	6000	f	1536	-10
196	12	16	6000	t	1664	10
197	15	16	6000	f	1536	-16
198	16	15	6000	f	1536	-16
199	15	14	6000	f	1536	-16
200	14	15	6000	f	1568	-16
211	12	14	952	t	1711	9
212	14	12	952	f	1542	-9
225	13	12	561	f	1670	-13
226	12	13	561	t	1747	13
123	8	7	743	t	1656	13
124	7	8	743	f	1598	-13
133	7	11	6000	t	1598	11
134	11	7	6000	f	1484	-11
141	7	9	743	f	1596	-13
142	9	7	743	t	1673	13
143	7	8	743	f	1596	-13
144	8	7	743	t	1673	13
145	10	8	968	f	1520	-9
146	8	10	968	t	1673	9
153	11	9	6000	f	1442	-7
154	9	11	6000	t	1673	7
155	11	8	6000	f	1442	-7
156	8	11	6000	t	1673	7
157	9	8	6000	f	1673	-16
158	8	9	6000	f	1673	-16
159	11	10	6000	f	1442	-12
160	10	11	6000	t	1520	12
169	12	14	952	t	1600	16
170	14	12	952	f	1600	-16
171	14	13	918	f	1600	-16
172	13	14	918	t	1600	16
173	16	13	6000	f	1600	-16
174	13	16	6000	t	1600	16
175	16	12	6000	f	1600	-16
176	12	16	6000	t	1600	16
177	16	15	6000	f	1600	-16
178	15	16	6000	f	1600	-16
179	15	14	6000	f	1600	-16
180	14	15	6000	f	1600	-16
187	15	12	876	f	1536	-10
188	12	15	876	t	1664	10
201	12	15	883	t	1711	7
202	15	12	883	f	1482	-7
205	12	13	771	t	1711	13
206	13	12	771	f	1654	-13
207	14	15	882	t	1542	13
208	15	14	882	f	1482	-13
221	16	14	743	f	1438	-11
222	14	16	743	t	1548	11
223	15	13	913	f	1437	-7
224	13	15	913	t	1670	7
227	15	12	876	f	1437	-5
228	12	15	876	t	1747	5
229	14	13	918	f	1548	-11
230	13	14	918	t	1670	11
231	14	12	899	f	1548	-8
232	12	14	899	t	1747	8
233	16	13	6000	f	1438	-7
234	13	16	6000	t	1670	7
235	16	12	6000	f	1438	-5
236	12	16	6000	t	1747	5
237	15	16	6000	f	1437	-16
238	16	15	6000	f	1438	-16
239	15	14	6000	f	1437	-16
240	14	15	6000	f	1548	-16
125	7	10	1049	t	1598	13
126	10	7	1049	f	1542	-13
135	9	11	6000	t	1656	9
136	11	9	6000	f	1484	-9
137	8	9	6000	f	1656	-16
138	9	8	6000	f	1656	-16
139	10	11	6000	t	1542	13
140	11	10	6000	f	1484	-13
149	10	9	1242	f	1520	-9
150	9	10	1242	t	1673	9
181	16	14	743	f	1536	-15
182	14	16	743	t	1568	15
189	14	13	918	f	1568	-13
190	13	14	918	t	1632	13
203	13	15	880	t	1654	9
204	15	13	880	f	1482	-9
209	14	16	743	t	1542	13
210	16	14	743	f	1483	-13
213	13	14	886	t	1654	11
214	14	13	886	f	1542	-11
215	12	16	6000	t	1711	7
216	16	12	6000	f	1483	-7
217	16	15	6000	f	1483	-16
218	15	16	6000	f	1482	-16
219	13	16	6000	t	1654	9
220	16	13	6000	f	1483	-9
241	17	21	333	t	1600	16
242	19	21	333	t	1600	16
243	21	17	333	f	1600	-16
244	21	19	333	f	1600	-16
245	17	20	406	t	1600	16
246	20	17	406	f	1600	-16
247	18	21	633	t	1600	16
248	21	18	633	f	1600	-16
249	19	20	406	t	1600	16
250	20	19	406	f	1600	-16
251	18	20	1054	t	1600	16
252	20	18	1054	f	1600	-16
253	18	19	1124	t	1600	16
254	19	18	1124	f	1600	-16
255	21	20	1379	t	1600	16
256	20	21	1379	f	1600	-16
257	17	18	1159	f	1600	-16
258	18	17	1159	t	1600	16
259	17	19	6000	f	1600	-16
260	19	17	6000	f	1600	-16
261	21	17	335	f	1568	-15
262	17	21	335	t	1600	15
263	20	17	415	f	1536	-13
264	17	20	415	t	1600	13
265	20	19	415	f	1536	-13
266	19	20	415	t	1600	13
267	21	19	335	f	1568	-15
268	19	21	335	t	1600	15
269	21	18	579	f	1568	-12
270	18	21	579	t	1664	12
271	20	18	999	f	1536	-10
272	20	21	872	f	1536	-15
273	21	20	872	t	1568	15
274	18	20	999	t	1664	10
275	19	18	1166	f	1600	-13
276	18	19	1166	t	1664	13
277	17	18	1159	f	1600	-13
278	18	17	1159	t	1664	13
279	19	17	6000	f	1600	-16
280	17	19	6000	f	1600	-16
281	19	21	333	t	1599	13
282	21	19	333	f	1541	-13
283	17	21	333	t	1599	13
284	21	17	333	f	1541	-13
285	17	20	406	t	1599	11
286	20	17	406	f	1485	-11
287	19	20	406	t	1599	11
288	20	19	406	f	1485	-11
289	18	21	633	t	1712	9
290	21	18	633	f	1541	-9
291	18	20	1054	t	1712	7
292	20	18	1054	f	1485	-7
293	18	19	1124	t	1712	11
294	19	18	1124	f	1599	-11
295	21	20	1379	t	1541	13
296	20	21	1379	f	1485	-13
297	18	17	1225	t	1712	11
298	17	18	1225	f	1599	-11
299	17	19	6000	f	1599	-16
300	19	17	6000	f	1599	-16
301	21	19	335	f	1519	-13
302	19	21	335	t	1596	13
303	21	17	335	f	1519	-13
304	17	21	335	t	1596	13
305	20	19	415	f	1443	-9
306	19	20	415	t	1596	9
307	20	17	415	f	1443	-9
308	17	20	415	t	1596	9
309	21	18	579	f	1519	-7
310	18	21	579	t	1750	7
311	20	18	999	f	1443	-5
312	18	20	999	t	1750	5
313	19	18	1166	f	1596	-9
314	18	19	1166	t	1750	9
315	20	21	872	f	1443	-13
316	21	20	872	t	1519	13
317	17	18	1159	f	1596	-9
318	18	17	1159	t	1750	9
319	19	17	6000	f	1596	-16
320	17	19	6000	f	1596	-16
321	22	25	1034	f	1600	-16
322	25	22	1034	t	1600	16
323	26	25	6000	f	1600	-16
324	25	26	6000	t	1600	16
326	26	22	6000	t	1600	16
325	24	25	6000	f	1600	-16
327	22	26	6000	f	1600	-16
328	25	24	6000	t	1600	16
329	24	23	6000	f	1600	-16
330	23	24	6000	t	1600	16
331	22	23	1033	t	1600	16
332	23	22	1033	f	1600	-16
333	23	25	6000	t	1600	16
334	25	23	6000	f	1600	-16
335	26	23	6000	f	1600	-16
336	23	26	6000	t	1600	16
347	22	23	1033	t	1568	19
348	23	22	1033	f	1632	-19
353	24	25	6000	f	1600	-15
354	25	24	6000	t	1632	15
363	25	22	965	t	1689	12
364	22	25	965	f	1607	-12
370	23	26	6000	t	1625	12
372	26	23	6000	f	1543	-12
375	23	24	6000	t	1625	12
376	24	23	6000	f	1536	-12
389	24	22	6000	t	1486	21
390	22	24	6000	f	1605	-21
397	24	26	6000	t	1486	18
398	26	24	6000	f	1524	-18
337	24	22	6000	t	1600	16
338	22	24	6000	f	1600	-16
357	24	23	6000	f	1600	-15
358	23	24	6000	t	1632	15
367	25	26	6000	t	1689	10
368	26	25	6000	f	1543	-10
383	22	25	1034	f	1605	-10
384	25	22	1034	t	1733	10
385	26	22	6000	t	1524	20
386	22	26	6000	f	1605	-20
393	24	23	6000	f	1486	-10
394	23	24	6000	t	1620	10
399	23	25	6000	t	1620	21
400	25	23	6000	f	1733	-21
339	24	26	6000	t	1600	16
340	26	24	6000	f	1600	-16
341	22	26	1033	t	1568	16
342	26	22	1033	f	1568	-16
345	22	24	1033	t	1568	17
346	24	22	1033	f	1600	-17
351	26	24	6000	t	1568	17
352	24	26	6000	f	1600	-17
355	26	23	6000	f	1568	-13
356	23	26	6000	t	1632	13
365	22	24	1033	t	1607	13
366	24	22	1033	f	1536	-13
369	25	24	6000	t	1689	9
371	24	25	6000	f	1536	-9
379	25	23	6000	t	1689	13
380	23	25	6000	f	1625	-13
381	22	23	1033	t	1605	17
382	23	22	1033	f	1620	-17
395	26	23	6000	f	1524	-12
396	23	26	6000	t	1620	12
343	22	25	1034	f	1568	-13
344	25	22	1034	t	1632	13
349	26	25	6000	f	1568	-13
350	25	26	6000	t	1632	13
359	25	23	6000	t	1632	16
360	23	25	6000	f	1632	-16
361	22	26	1033	t	1607	13
362	26	22	1033	f	1543	-13
373	23	22	6000	f	1625	-16
374	22	23	6000	f	1607	-16
377	26	24	6000	t	1543	16
378	24	26	6000	f	1536	-16
387	26	25	6000	f	1524	-7
388	25	26	6000	t	1733	7
391	24	25	6000	f	1486	-6
392	25	24	6000	t	1733	6
401	27	29	608	f	1600	-16
402	29	27	608	t	1600	16
403	28	30	702	t	1600	16
404	30	28	702	f	1600	-16
405	30	29	681	f	1600	-16
406	29	30	681	t	1600	16
407	30	31	773	f	1600	-16
408	31	30	773	t	1600	16
409	27	31	635	f	1600	-16
410	31	27	635	t	1600	16
411	28	31	6000	t	1600	16
412	31	28	6000	f	1600	-16
413	28	29	6000	t	1600	16
414	29	28	6000	f	1600	-16
415	28	27	602	t	1600	16
416	27	28	602	f	1600	-16
417	29	31	6000	t	1600	16
418	31	29	6000	f	1600	-16
419	27	30	6000	t	1600	16
420	30	27	6000	f	1600	-16
421	27	31	635	f	1568	-15
422	31	27	635	t	1600	15
423	30	29	681	f	1536	-12
424	29	30	681	t	1632	12
425	27	29	608	f	1568	-13
426	29	27	608	t	1632	13
427	30	31	773	f	1536	-13
428	31	30	773	t	1600	13
429	27	28	1055	f	1568	-12
430	28	27	1055	t	1664	12
431	30	28	1196	f	1536	-10
432	28	30	1196	t	1664	10
433	30	27	1182	f	1536	-15
434	27	30	1182	t	1568	15
435	31	29	6000	t	1600	17
436	29	31	6000	f	1632	-17
437	31	28	6000	t	1600	19
438	28	31	6000	f	1664	-19
439	29	28	6000	t	1632	17
440	28	29	6000	f	1664	-17
441	29	27	578	t	1657	11
442	27	29	578	f	1543	-11
443	31	30	701	t	1664	8
444	30	31	701	f	1486	-8
445	31	27	572	t	1664	11
446	27	31	572	f	1543	-11
447	29	30	756	t	1657	9
448	30	29	756	f	1486	-9
449	28	27	602	t	1650	11
450	27	28	602	f	1543	-11
451	28	30	702	t	1650	9
452	30	28	702	f	1486	-9
453	31	29	6000	t	1664	16
454	29	31	6000	f	1657	-16
455	31	28	6000	t	1664	15
456	28	31	6000	f	1650	-15
457	29	28	6000	t	1657	16
458	28	29	6000	f	1650	-16
459	27	30	6000	t	1543	13
460	30	27	6000	f	1486	-13
461	27	29	608	f	1523	-9
462	29	27	608	t	1677	9
463	30	29	681	f	1447	-7
464	29	30	681	t	1677	7
465	27	31	635	f	1523	-8
466	31	27	635	t	1714	8
467	27	28	1055	f	1523	-11
468	28	27	1055	t	1639	11
469	30	31	773	f	1447	-6
470	31	30	773	t	1714	6
471	30	27	1182	f	1447	-13
472	27	30	1182	t	1523	13
473	28	29	6000	t	1639	18
474	29	28	6000	f	1677	-18
475	30	28	1196	f	1447	-8
476	28	30	1196	t	1639	8
477	28	31	6000	t	1639	19
478	31	28	6000	f	1714	-19
479	29	31	6000	t	1677	18
480	31	29	6000	f	1714	-18
481	32	35	705	t	1600	16
482	35	32	705	f	1600	-16
483	34	35	705	t	1600	16
484	35	34	705	f	1600	-16
485	36	35	1244	t	1600	16
486	35	36	1244	f	1600	-16
487	33	35	1248	t	1600	16
488	35	33	1248	f	1600	-16
489	32	33	1458	f	1600	-16
490	33	32	1458	t	1600	16
491	32	34	1586	t	1600	16
492	34	32	1586	f	1600	-16
493	34	33	2282	t	1600	16
494	33	34	2282	f	1600	-16
495	36	34	2571	f	1600	-16
496	34	36	2571	t	1600	16
497	36	32	2145	f	1600	-16
498	32	36	2145	t	1600	16
499	36	33	2727	f	1600	-16
500	33	36	2727	t	1600	16
501	35	32	705	f	1536	-12
502	32	35	705	t	1632	12
503	35	34	704	f	1536	-12
504	34	35	704	t	1632	12
505	35	33	1382	f	1536	-12
506	33	35	1382	t	1632	12
519	36	33	2727	f	1568	-13
520	33	36	2727	t	1632	13
521	36	35	1244	t	1544	13
522	35	36	1244	f	1485	-13
539	33	36	2329	f	1625	-20
540	36	33	2329	t	1544	20
541	35	32	705	f	1445	-6
542	32	35	705	t	1703	6
553	36	34	2571	f	1556	-11
554	34	36	2571	t	1677	11
557	34	32	1695	f	1677	-15
558	32	34	1695	t	1703	15
507	35	36	1323	f	1536	-15
508	36	35	1323	t	1568	15
514	33	32	1801	f	1632	-16
515	32	33	1801	t	1632	16
524	33	35	1248	t	1625	10
526	35	33	1248	f	1485	-10
529	34	35	705	t	1657	9
530	35	34	705	f	1485	-9
533	32	34	1586	t	1689	15
534	34	32	1586	f	1657	-15
537	34	36	2361	t	1657	11
538	36	34	2361	f	1544	-11
549	33	34	2486	f	1619	-13
550	34	33	2486	t	1677	13
509	33	34	2486	f	1632	-16
510	34	33	2486	t	1632	16
513	34	32	1695	f	1632	-16
516	32	34	1695	t	1632	16
517	36	34	2571	f	1568	-13
518	34	36	2571	t	1632	13
523	32	35	705	t	1689	8
525	35	32	705	f	1485	-8
527	32	36	2100	t	1689	10
528	36	32	2100	f	1544	-10
531	32	33	1458	f	1689	-19
532	33	32	1458	t	1625	19
543	35	36	1323	f	1445	-11
544	36	35	1323	t	1556	11
547	35	34	704	f	1445	-7
548	34	35	704	t	1677	7
551	36	32	2145	f	1556	-10
552	32	36	2145	t	1703	10
559	36	33	2727	f	1556	-13
560	33	36	2727	t	1619	13
511	36	32	2145	f	1568	-13
512	32	36	2145	t	1632	13
535	34	33	2282	t	1657	15
536	33	34	2282	f	1625	-15
545	35	33	1382	f	1445	-9
546	33	35	1382	t	1619	9
555	33	32	1801	f	1619	-12
556	32	33	1801	t	1703	12
561	39	41	627	t	1600	16
562	41	39	627	f	1600	-16
563	40	41	904	t	1600	16
564	41	40	904	f	1600	-16
565	40	37	625	f	1600	-16
566	37	40	625	t	1600	16
567	40	39	693	t	1600	16
568	39	40	693	f	1600	-16
569	38	41	6000	t	1600	16
570	41	38	6000	f	1600	-16
571	38	40	765	f	1600	-16
572	40	38	765	t	1600	16
573	38	37	959	f	1600	-16
574	37	38	959	t	1600	16
575	41	37	977	f	1600	-16
576	37	41	977	t	1600	16
577	38	39	6000	t	1600	16
578	39	38	6000	f	1600	-16
579	39	37	6000	t	1600	16
580	37	39	6000	f	1600	-16
581	39	38	892	t	1600	16
582	38	39	892	f	1600	-16
583	41	40	772	f	1536	-12
584	40	41	772	t	1632	12
585	39	40	842	t	1600	17
586	40	39	842	f	1632	-17
587	41	38	6000	t	1536	19
588	38	41	6000	f	1600	-19
589	41	37	977	f	1536	-12
590	37	41	977	t	1632	12
591	37	40	696	t	1632	16
592	40	37	696	f	1632	-16
593	38	37	959	f	1600	-15
594	37	38	959	t	1632	15
595	38	40	765	f	1600	-15
596	40	38	765	t	1632	15
597	41	39	6000	t	1536	19
598	39	41	6000	f	1600	-19
599	39	37	6000	t	1600	17
600	37	39	6000	f	1632	-17
601	39	41	627	t	1631	12
602	41	39	627	f	1550	-12
603	39	38	892	t	1631	12
604	38	39	892	f	1535	-12
605	40	38	822	t	1626	12
606	38	40	822	f	1535	-12
607	37	38	1031	t	1658	11
608	38	37	1031	f	1535	-11
609	39	40	842	t	1631	16
610	40	39	842	f	1626	-16
611	37	40	696	t	1658	15
612	40	37	696	f	1626	-15
613	40	41	904	t	1626	13
614	41	40	904	f	1550	-13
615	37	41	1117	t	1658	11
616	41	37	1117	f	1550	-11
617	41	38	6000	t	1550	15
618	38	41	6000	f	1535	-15
619	37	39	1182	t	1658	15
620	39	37	1182	f	1631	-15
621	40	39	693	t	1620	18
622	39	40	693	f	1656	-18
623	41	40	772	f	1529	-12
624	40	41	772	t	1620	12
625	41	37	977	f	1529	-8
626	37	41	977	t	1710	8
627	38	41	6000	t	1485	18
628	41	38	6000	f	1529	-18
629	40	37	625	f	1620	-12
630	37	40	625	t	1710	12
631	38	40	765	f	1485	-10
632	40	38	765	t	1620	10
633	41	39	6000	t	1529	22
634	39	41	6000	f	1656	-22
635	38	39	6000	t	1485	23
636	39	38	6000	f	1656	-23
637	38	37	959	f	1485	-7
638	37	38	959	t	1710	7
639	39	37	6000	t	1656	18
640	37	39	6000	f	1710	-18
641	42	46	742	t	1600	16
642	46	42	742	f	1600	-16
643	45	43	452	t	1600	16
644	43	45	452	f	1600	-16
645	44	46	1271	t	1600	16
646	46	44	1271	f	1600	-16
647	44	43	1286	f	1600	-16
648	43	44	1286	t	1600	16
649	45	46	729	t	1600	16
650	46	45	729	f	1600	-16
651	42	43	1111	f	1600	-16
652	43	42	1111	t	1600	16
653	46	43	1408	t	1600	16
654	43	46	1408	f	1600	-16
655	44	42	1220	f	1600	-16
656	42	44	1220	t	1600	16
657	44	45	6000	f	1600	-16
658	45	44	6000	t	1600	16
659	42	45	6000	f	1600	-16
660	45	42	6000	f	1600	-16
661	46	43	1408	t	1568	17
662	43	46	1408	f	1600	-17
663	44	42	1220	f	1568	-15
664	42	44	1220	t	1600	15
665	46	44	1230	f	1568	-16
666	44	46	1230	t	1568	16
667	46	45	743	f	1568	-13
668	45	46	743	t	1632	13
669	46	42	770	f	1568	-15
670	42	46	770	t	1600	15
671	44	43	1286	f	1568	-15
672	43	44	1286	t	1600	15
673	43	45	625	f	1600	-15
674	45	43	625	t	1632	15
681	45	46	729	t	1657	11
682	46	45	729	f	1541	-11
709	46	43	1408	t	1488	22
710	43	46	1408	f	1628	-22
729	48	51	852	f	1600	-16
730	51	48	852	t	1600	16
755	51	49	6000	f	1600	-16
756	49	51	6000	f	1600	-16
791	48	50	971	f	1436	-13
792	50	48	971	t	1512	13
675	43	42	1624	t	1600	16
676	42	43	1624	f	1600	-16
683	44	46	1271	t	1541	16
684	46	44	1271	f	1541	-16
697	45	42	6000	f	1657	-16
698	42	45	6000	f	1598	-16
739	47	49	6000	f	1600	-16
740	49	47	6000	f	1600	-16
743	50	51	895	f	1568	-15
744	51	50	895	t	1600	15
769	47	48	1091	t	1596	11
770	48	47	1091	f	1482	-11
775	47	51	6000	f	1596	-16
776	51	47	6000	f	1596	-16
781	48	49	860	f	1436	-9
782	49	48	860	t	1588	9
787	48	51	852	f	1436	-9
788	51	48	852	t	1588	9
799	49	47	6000	f	1588	-16
800	47	49	6000	f	1588	-16
677	44	45	6000	f	1568	-13
678	45	44	6000	t	1632	13
695	43	44	1746	t	1599	13
696	44	43	1746	f	1541	-13
717	44	45	6000	f	1520	-9
718	45	44	6000	t	1676	9
749	48	49	860	f	1536	-13
750	49	48	860	t	1600	13
767	51	48	829	t	1596	11
768	48	51	829	f	1482	-11
795	51	49	6000	f	1588	-16
796	49	51	6000	f	1588	-16
679	42	45	6000	f	1600	-16
680	45	42	6000	f	1632	-16
689	42	44	1039	t	1598	13
690	44	42	1039	f	1541	-13
719	42	45	6000	f	1592	-16
720	45	42	6000	f	1676	-16
757	51	47	6000	f	1600	-16
758	47	51	6000	f	1600	-16
765	49	50	754	t	1596	13
766	50	49	754	f	1538	-13
685	42	46	742	t	1598	13
686	46	42	742	f	1541	-13
699	45	44	6000	t	1657	11
700	44	45	6000	f	1541	-11
703	42	43	1111	f	1592	-14
704	43	42	1111	t	1628	14
713	46	44	1230	f	1488	-15
714	44	46	1230	t	1520	15
721	50	49	716	f	1600	-16
722	49	50	716	t	1600	16
725	48	49	860	f	1600	-16
726	49	48	860	t	1600	16
737	47	51	6000	f	1600	-16
738	51	47	6000	f	1600	-16
746	48	47	1080	f	1536	-13
748	47	48	1080	t	1600	13
759	49	47	6000	f	1600	-16
760	47	49	6000	f	1600	-16
779	47	49	6000	f	1596	-16
780	49	47	6000	f	1596	-16
789	50	51	895	f	1512	-13
790	51	50	895	t	1588	13
687	45	43	452	t	1657	13
688	43	45	452	f	1599	-13
705	46	42	770	f	1488	-11
706	42	46	770	t	1592	11
727	50	51	895	f	1600	-16
728	51	50	895	t	1600	16
733	48	47	1080	f	1600	-16
734	47	48	1080	t	1600	16
753	48	50	971	f	1536	-15
754	50	48	971	t	1568	15
771	50	48	870	t	1538	13
772	48	50	870	f	1482	-13
777	49	51	6000	f	1596	-16
778	51	49	6000	f	1596	-16
783	50	49	716	f	1512	-13
784	49	50	716	t	1588	13
793	50	47	893	f	1512	-13
794	47	50	893	t	1588	13
691	43	46	1798	t	1599	13
692	46	43	1798	f	1541	-13
701	46	45	743	f	1488	-8
702	45	46	743	t	1676	8
711	43	45	625	f	1628	-14
712	45	43	625	t	1676	14
723	47	50	783	t	1600	16
724	50	47	783	f	1600	-16
731	48	50	971	f	1600	-16
732	50	48	971	t	1600	16
735	49	51	6000	f	1600	-16
736	51	49	6000	f	1600	-16
741	50	49	716	f	1568	-15
742	49	50	716	t	1600	15
745	48	51	852	f	1536	-13
747	51	48	852	t	1600	13
751	50	47	893	f	1568	-15
752	47	50	893	t	1600	15
761	47	50	783	t	1596	13
762	50	47	783	f	1538	-13
773	49	48	989	t	1596	11
774	48	49	989	f	1482	-11
797	51	47	6000	f	1588	-16
798	47	51	6000	f	1588	-16
693	43	42	1624	t	1599	16
694	42	43	1624	f	1598	-16
707	44	43	1286	f	1520	-11
708	43	44	1286	t	1628	11
715	44	42	1220	f	1520	-13
716	42	44	1220	t	1592	13
763	51	50	755	t	1596	13
764	50	51	755	f	1538	-13
785	48	47	1080	f	1436	-9
786	47	48	1080	t	1588	9
801	52	54	1165	t	1600	16
802	54	52	1165	f	1600	-16
803	54	53	1540	f	1600	-16
804	53	54	1540	t	1600	16
805	52	53	1165	t	1600	16
806	53	52	1165	f	1600	-16
807	55	56	1105	f	1600	-16
808	56	55	1105	t	1600	16
809	53	56	6000	t	1600	16
810	56	53	6000	f	1600	-16
811	54	56	6000	t	1600	16
812	56	54	6000	f	1600	-16
814	55	54	6000	t	1600	16
815	54	55	6000	f	1600	-16
813	52	55	6000	f	1600	-16
816	55	52	6000	t	1600	16
817	55	53	6000	t	1600	16
818	53	55	6000	f	1600	-16
819	52	56	6000	t	1600	16
820	56	52	6000	f	1600	-16
821	54	53	1540	f	1568	-15
822	53	54	1540	t	1600	15
823	55	52	1640	f	1632	-16
824	52	55	1640	t	1632	16
825	56	53	6000	f	1568	-15
826	53	56	6000	t	1600	15
827	53	55	6000	t	1600	17
829	55	53	6000	f	1632	-17
828	56	55	6000	f	1568	-13
830	55	56	6000	t	1632	13
831	54	52	6000	t	1568	19
832	52	54	6000	f	1632	-19
833	54	55	6000	t	1568	19
834	55	54	6000	f	1632	-19
835	56	54	6000	f	1568	-16
836	54	56	6000	t	1568	16
837	56	52	6000	f	1568	-13
838	52	56	6000	t	1632	13
839	53	52	6000	t	1600	17
840	52	53	6000	f	1632	-17
841	55	56	1105	f	1593	-20
842	56	55	1105	t	1511	20
843	53	54	1540	f	1664	-19
844	54	53	1540	t	1607	19
845	52	54	1165	t	1625	15
846	54	52	1165	f	1607	-15
847	54	56	6000	t	1607	12
848	56	54	6000	f	1511	-12
849	52	55	6000	f	1625	-17
850	55	52	6000	t	1593	17
851	53	55	6000	t	1664	13
852	55	53	6000	f	1593	-13
853	54	55	6000	t	1607	15
854	55	54	6000	f	1593	-15
855	53	56	6000	t	1664	9
856	56	53	6000	f	1511	-9
857	53	52	6000	t	1664	14
858	52	53	6000	f	1625	-14
859	52	56	6000	t	1625	11
860	56	52	6000	f	1511	-11
861	52	54	1165	t	1620	17
862	54	52	1165	f	1638	-17
863	54	53	1540	f	1638	-14
864	53	54	1540	t	1681	14
865	52	53	1165	t	1620	19
866	53	52	1165	f	1681	-19
867	55	52	1640	f	1562	-13
868	52	55	1640	t	1620	13
869	56	53	6000	f	1499	-8
870	53	56	6000	t	1681	8
871	56	54	6000	f	1499	-10
872	54	56	6000	t	1638	10
873	55	53	6000	t	1562	21
874	53	55	6000	f	1681	-21
875	56	55	6000	f	1499	-13
876	55	56	6000	t	1562	13
877	55	54	6000	t	1562	19
878	54	55	6000	f	1638	-19
879	56	52	6000	f	1499	-11
880	52	56	6000	t	1620	11
881	57	58	438	t	1600	16
882	58	57	438	f	1600	-16
883	61	57	437	f	1600	-16
884	57	61	437	t	1600	16
885	60	57	437	f	1600	-16
886	57	60	437	t	1600	16
887	59	57	437	f	1600	-16
888	57	59	437	t	1600	16
889	61	58	1330	f	1600	-16
890	58	61	1330	t	1600	16
891	59	58	1330	f	1600	-16
892	58	59	1330	t	1600	16
893	61	60	1370	t	1600	16
894	60	61	1370	f	1600	-16
895	59	60	1370	t	1600	16
896	60	59	1370	f	1600	-16
897	60	58	1270	t	1600	16
898	58	60	1270	f	1600	-16
899	61	59	1330	f	1600	-16
900	59	61	1330	t	1600	16
901	61	57	437	f	1568	-12
902	60	57	437	f	1568	-12
904	57	60	437	t	1664	12
903	57	61	437	t	1664	12
905	58	57	437	f	1600	-13
906	57	58	437	t	1664	13
907	58	59	1330	f	1600	-16
908	59	58	1330	t	1600	16
909	60	58	1270	t	1568	17
910	58	60	1270	f	1600	-17
911	59	57	437	f	1600	-13
912	57	59	437	t	1664	13
933	57	60	430	t	1714	11
934	60	57	430	f	1606	-11
939	60	59	1270	t	1606	16
940	59	60	1270	f	1601	-16
942	61	57	437	f	1529	-7
944	57	61	437	t	1754	7
959	59	58	1330	f	1537	-16
960	58	59	1330	t	1543	16
913	60	61	1270	t	1568	16
914	61	60	1270	f	1568	-16
929	60	61	1270	t	1606	12
930	61	60	1270	f	1510	-12
945	58	57	437	f	1543	-7
946	57	58	437	t	1754	7
915	60	59	1270	t	1568	17
916	59	60	1270	f	1600	-17
925	57	59	438	t	1714	11
926	59	57	438	f	1601	-11
937	60	58	1270	t	1606	14
938	58	60	1270	f	1569	-14
941	59	57	437	f	1537	-7
943	57	59	437	t	1754	7
947	61	58	1330	f	1529	-15
948	58	61	1330	t	1543	15
955	61	59	1330	f	1529	-16
956	59	61	1330	t	1537	16
917	61	58	1330	f	1568	-15
918	58	61	1330	t	1600	15
921	57	58	438	t	1714	10
922	58	57	438	f	1569	-10
927	59	61	1330	f	1601	-20
928	61	59	1330	t	1510	20
931	59	58	1330	f	1601	-17
932	58	59	1330	t	1569	17
949	59	60	1370	t	1537	20
950	60	59	1370	f	1637	-20
919	61	59	1330	f	1568	-15
920	59	61	1330	t	1600	15
923	57	61	438	t	1714	8
924	61	57	438	f	1510	-8
935	58	61	1330	f	1569	-19
936	61	58	1330	t	1510	19
951	58	60	1370	t	1543	20
952	60	58	1370	f	1637	-20
957	60	57	437	f	1637	-11
958	57	60	437	t	1754	11
953	61	60	1370	t	1529	21
954	60	61	1370	f	1637	-21
961	64	62	582	f	1600	-16
962	62	64	582	t	1600	16
963	65	66	1017	t	1600	16
964	66	65	1017	f	1600	-16
965	64	66	969	f	1600	-16
966	66	64	969	t	1600	16
967	63	66	1056	f	1600	-16
968	66	63	1056	t	1600	16
969	63	65	1028	f	1600	-16
970	65	63	1028	t	1600	16
971	64	63	1007	t	1600	16
972	63	64	1007	f	1600	-16
973	63	62	633	f	1600	-16
974	62	63	633	t	1600	16
975	62	66	1012	t	1600	16
976	66	62	1012	f	1600	-16
977	64	65	1031	f	1600	-16
978	65	64	1031	t	1600	16
979	62	65	1012	t	1600	16
980	65	62	1012	f	1600	-16
981	64	62	582	f	1568	-12
982	62	64	582	t	1664	12
983	63	64	1501	t	1536	17
984	64	63	1501	f	1568	-17
985	63	62	633	f	1536	-10
986	62	63	633	t	1664	10
987	66	62	693	f	1600	-13
988	62	66	693	t	1664	13
989	66	65	1076	f	1600	-15
990	65	66	1076	t	1632	15
991	64	66	969	f	1568	-15
993	66	64	969	t	1600	15
992	63	66	1056	f	1536	-13
994	66	63	1056	t	1600	13
995	64	65	1031	f	1568	-13
996	65	64	1031	t	1632	13
997	65	62	693	f	1632	-15
998	62	65	693	t	1664	15
999	63	65	1028	f	1536	-12
1000	65	63	1028	t	1632	12
1001	66	63	1000	t	1600	12
1002	63	66	1000	f	1518	-12
1004	65	66	1017	t	1657	13
1003	65	63	1194	t	1657	10
1006	63	65	1194	f	1518	-10
1005	66	65	1017	f	1600	-13
1007	63	64	1501	t	1518	16
1008	64	63	1501	f	1511	-16
1009	66	64	1047	t	1600	12
1010	64	66	1047	f	1511	-12
1011	62	66	1012	t	1714	11
1012	66	62	1012	f	1600	-11
1013	62	63	763	t	1714	8
1014	63	62	763	f	1518	-8
1015	62	64	1071	t	1714	8
1016	64	62	1071	f	1511	-8
1017	65	64	841	f	1657	-22
1018	64	65	841	t	1511	22
1019	62	65	1012	t	1714	13
1020	65	62	1012	f	1657	-13
1021	64	63	1007	t	1497	16
1022	63	64	1007	f	1504	-16
1023	64	62	582	f	1497	-6
1024	62	64	582	t	1754	6
1025	63	62	633	f	1504	-6
1026	62	63	633	t	1754	6
1027	63	66	1056	f	1504	-12
1028	66	63	1056	t	1600	12
1029	64	66	969	f	1497	-11
1030	66	64	969	t	1600	11
1031	66	62	693	f	1600	-9
1032	62	66	693	t	1754	9
1033	63	65	1028	f	1504	-10
1034	65	63	1028	t	1645	10
1035	66	65	1076	f	1600	-14
1036	65	66	1076	t	1645	14
1037	64	65	1031	f	1497	-10
1038	65	64	1031	t	1645	10
1039	65	62	693	f	1645	-11
1040	62	65	693	t	1754	11
\.


--
-- Name: activations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.activations_id_seq', 11780, true);


--
-- Name: bots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bots_id_seq', 70, true);


--
-- Name: match_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.match_results_id_seq', 1040, true);


--
-- PostgreSQL database dump complete
--

\unrestrict IiJzc6gZeu64Uf1Iy2E5HolxvWuOmtxRVOkzhGsqvtIgn1ZheEjg5BFUG4dfDsf

